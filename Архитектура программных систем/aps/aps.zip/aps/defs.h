//
//  defs.h
//  Created by Alina Potapova on 22.04.2022.
//

#define MAX_TASK 32
#define MAX_RES 16

